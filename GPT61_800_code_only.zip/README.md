# GPT-6.1 code-switch prediction

分享代码只需这三个文件：`cs_predict_gpt61_800.py`、`requirements.txt`、本说明。
核心代码只有一个 .py，不依赖 prepare.py、run.py、score.py 或 expand_800.py。

配置：12 个语言对，每对 800 test（400 SWITCH / 400 NO_SWITCH）+ 100 validation。
模型固定为 gpt-6.1-sol，low reasoning，40 条/批。模型通过已登录的 Codex CLI 调用，
需要对该模型有访问权限；仅有 ChatGPT 桌面 App 不等于已安装并登录 Codex CLI。

## 从原始 CSV 运行

```powershell
python -m pip install -r requirements.txt
python cs_predict_gpt61_800.py sample --data-dir "D:/SwitchLingua_text"
python cs_predict_gpt61_800.py run
python cs_predict_gpt61_800.py eval --data-dir "D:/SwitchLingua_text"
```

也可 `python cs_predict_gpt61_800.py all --data-dir "D:/SwitchLingua_text"`。
CSV 须包含 Arabic_eng、Chinese_eng、French_eng、German_Eng、Hindi_eng、Italian_eng、
Japanese_eng、Korean_eng、Malay_eng、Philippines_eng、Russian_eng、Spanish_eng，扩展名 .csv。
默认数据目录为代码旁的 gpt61_800_data；可用 --work-dir 自定义。
默认结果在 WORK_DIR/metrics；可用 --output-dir 自定义。
输出包括 switch Accuracy/Precision/Recall/F1、duration Accuracy/macro-F1、joint Accuracy、
标点基线、组合结果、置信区间、逐条预测、输入和参考标签，以及方法报告。
评估代码不自动生成 Excel；已完成实验的 Excel 在完整结果包中。

## 核对已经跑完的这次结果（不需要再次调用模型）

从完整结果包取得 reproducibility/experiment_12/v3_800 文件夹，保留其全部内容，然后：

```powershell
python cs_predict_gpt61_800.py eval --data-dir "D:/SwitchLingua_text" --work-dir "D:/v3_800" --output-dir "D:/gpt_metrics"
```

需要原始 12 个 CSV，代码会验证源文件哈希。不要对带有已完成响应的 v3_800 再运行 sample。
若其他模型要做公平比较，应使用完整结果包里的 test_inputs.jsonl 和 test_ground_truth.csv，
而不是各自重新抽样。只分享代码可运行同一方案，但不能保证重跑得到完全相同的模型输出。

## 实验边界

输入只有 ID、语言对、已观测 prefix 和 current token，不含未来词或说话人信息。
prefix 保留已观测标点；combined 是同一标点线索的规则融合，不是增加说话人元数据。
标签是 Unicode/Lingua 自动生成的 silver labels；过滤和标点分布可能使任务更容易。
duration 是文本单位长度，不是时间。样本均衡不代表真实世界切换率。
模型请求无工具调用，原始事件记录和格式校验保留；服务端固定模型快照不可见。
